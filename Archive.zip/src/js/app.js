
import $ from "./jquery/src/jquery.js";
$('#message').text('Hi from jQuery!');