# fashion-temp


First install dependencies

```
npm i
``` 

Then

```
npm run start
```
or 
```
npm run serve
````
